jQuery.noConflict(); // Allow the test to run with other libs or jQuery's.
